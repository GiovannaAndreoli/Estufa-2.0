Projeto criado usando a linguagem Java, conceitos de POO e estrutura de banco de dados SQL.
